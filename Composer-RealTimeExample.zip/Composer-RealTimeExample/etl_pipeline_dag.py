#import libraries
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import BranchPythonOperator,PythonOperator
from datetime import datetime, timedelta
from time import gmtime, strftime
from airflow import models
from airflow.providers.google.cloud.operators import dataproc
from airflow.utils.trigger_rule import TriggerRule
import airflow
from airflow.models import Variable
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.google.cloud.operators.dataproc import DataprocSubmitPySparkJobOperator, DataprocSubmitJobOperator
import json
from airflow.operators.python_operator import PythonOperator
import os
import logging
import sys
from airflow.utils.dates import days_ago
from airflow.exceptions import AirflowException
import datetime
from google.cloud import storage
#import logging logic
import logging
# Imports the Google Cloud client library
from google.cloud import logging
from google.cloud.logging.handlers import CloudLoggingHandler
import json 

bucket = "us-east1-stobg-composer-tes-3888c6a1-bucket"

def get_json(bucket): 
    storage_client = storage.Client()
    bucket = storage_client.get_bucket(bucket)
    blob = bucket.blob("config_dag/config_dag.json")
    data = json.loads(blob.download_as_string())
    return data

config = get_json(bucket)


project_id = config["project_id"]
region = config["region"]
zone = config["zone"]
storage_bucket = config["storage_bucket"]
cluster_name = config["cluster_name"]
service_account =  config["service_account"] 

ingestion_file = config["ingestion_file"]
load_hub_table_file = config["load_hub_table_file"]
load_mart_table_file = config["load_mart_table_file"]
load_mart_view_file = config["load_mart_view_file"]


default_args = {
    "owner":config["owner"],
    "depends_on_past" : config["depends_on_past"],
    "start_date":airflow.utils.dates.days_ago(config["start_date"]),
    "email_on_failure":config["email_on_failure"],
    "email_on_retry":config["email_on_retry"],
    "retries": config["retries"],
    "retry_delay":timedelta(minutes=config["retry_delay"]),
    "project_id":project_id
}


#Creating DAG Object:
dag = DAG(
        config["dag_name"],
        default_args=default_args,
        max_active_runs=10,
        schedule_interval= '0 7 * * *', 
        catchup=False,
        description=config["dag_description"],
        tags=config["dag_tags"]
)
    
start=DummyOperator(
    task_id=config["start_task_id"],
    dag=dag
    )
    

cluster_configuration = dataproc.ClusterGenerator(
        service_account_scopes=config["service_account_scopes"],
        image_version=config["image_version"], 
        init_actions_uris=config["init_actions_uris"],
        properties=config["properties"],
        num_workers=config["num_workers"],
        storage_bucket =storage_bucket,
        labels =config["labels"],
        tags=config["cluster_tags"],
        project_id=project_id,
        region=region,
        zone=None,      # zone = zone to run a cluster on a specific one
        master_machine_type=config["master_machine_type"],
        worker_machine_type=config["worker_machine_type"],
        service_account = service_account, #current one associated with composer this may vary in future.
        metadata=config["cluster_metadata"],  
        master_disk_size = config["master_disk_size"],
        worker_disk_size = config["worker_disk_size"],
        num_preemptible_workers = config["num_preemptible_workers"]
        ).make()

create_cluster = dataproc.DataprocCreateClusterOperator(
        task_id=config["create_cluster_task_id"],
        cluster_name=cluster_name,
        project_id=project_id,
        region=region,
        cluster_config=cluster_configuration,
	    dag=dag
)


		  
run_Job1 = DataprocSubmitPySparkJobOperator(
          task_id=config["run_Job1_task_id"],
          main = ingestion_file,
          dataproc_jars = config["dataproc_jars"],
	      cluster_name = cluster_name,
          region = region,
          project_id = project_id,
          dag=dag,
          pyfiles = [config["config_ingestion"]]
          )
          
run_Job2 = DataprocSubmitPySparkJobOperator(
          task_id=config["run_Job2_task_id"],
          main = load_hub_table_file,
          dataproc_jars = config["dataproc_jars"],
	      cluster_name = cluster_name,
          region = region,
          project_id = project_id,
          dag=dag,
          pyfiles = [config["config_transformation"]]
          )
          
run_Job3 = DataprocSubmitPySparkJobOperator(
          task_id=config["run_Job3_task_id"],
          main = load_mart_table_file,
          dataproc_jars = config["dataproc_jars"],
	      cluster_name = cluster_name,
          region = region,
          project_id = project_id,
          dag=dag,
          pyfiles = [config["config_transformation"]]
          )
          
run_Job4 = DataprocSubmitPySparkJobOperator(
          task_id=config["run_Job4_task_id"],
          main = load_mart_view_file,
          dataproc_jars = config["dataproc_jars"],
	      cluster_name = cluster_name,
          region = region,
          project_id = project_id,
          dag=dag,
          pyfiles = [config["config_transformation"]]
          )

	  
delete_cluster = dataproc.DataprocDeleteClusterOperator(
            task_id=config["delete_cluster_task_id"],
            cluster_name=cluster_name,
            project_id=project_id,
            region=region,
            trigger_rule=TriggerRule.ALL_DONE,
            dag=dag
            )

end=DummyOperator(
    task_id=config["end_task_id"],
    dag=dag
    )  


start >> create_cluster >> run_Job1 >> run_Job2 >> run_Job3 >> run_Job4 >> delete_cluster >> end
